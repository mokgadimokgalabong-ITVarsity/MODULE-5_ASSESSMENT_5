# superhero-app
Live preview: http://superheroesapp.mateuszrajek.pl/

react.js app created using superhero api from https://superheroapi.com/

There is a "Moesif CORS" Chrome extension required to use this app

![moesif cors](https://user-images.githubusercontent.com/62522817/89653164-867dd200-d8be-11ea-8c30-8188ea6513f9.png)

!!!As there is a problem with Landing page it has been deactivated temporarily and the token is already applied!!!
/* There is an api token required for this app. *!!!The Landing Page with token field does not work properly and needs to be fixed.!!!* It can be taken from https://superheroapi.com/ (needs a facebook account to generate token). 
If you are a recruiter the token has been sent via email together with my application.*/

!!! The Landing Page with token field does not work properly and needs to be fixed. !!!

You can search for your favourite hero by typing the name of some "key word". 
### Example: if you want to find a Superman - type 'super' 
![nav heroes](https://user-images.githubusercontent.com/62522817/88208475-2d206c80-cc49-11ea-9a6e-b92ccaa41011.jpg)

### All heroes with 'super' in their names will show up:

![super search view](https://user-images.githubusercontent.com/62522817/88209535-c1d79a00-cc4a-11ea-8ce0-cd1bf14430fa.jpg)

### By clicking the picture you will get the details view of your choosen hero: 

![superman detils view](https://user-images.githubusercontent.com/62522817/88209575-cd2ac580-cc4a-11ea-9c03-ff34e45d9489.jpg)
